package _bear;

import java.util.Arrays;

/**
 * @Author: bear
 * @Date: 08/05/2018 19:19
 * @Description:
 */
public class KthLargest {
    public static void main(String[] args) throws Exception {
        int[] a = new int[]{2,7,12,5,0,0};
        KthLargest kthLargest = new KthLargest();
        int i = kthLargest.KthLargest(a, 3);
        System.out.println(i);

        utils.PrintUtils.printArray(a,"a");
    }

    //time  complexity is nlog(n)
    public int KthLargest(int[] nums, int k) throws Exception{
        if (nums == null || nums.length < 2) throw new IllegalArgumentException();
        int len = nums.length;
        if (k < 0 || len < k) throw new IllegalArgumentException();

        Arrays.sort(nums);
        int i = 1;
        int j = len - 1;
        int index = 0;

        while (i < k) {
            index += i;
            j --;
            i++;
        }

        return nums[len - i - 1];
    }
}
